---
template: home.html
title: Chavinci Network
social:
  cards_layout_options:
    title: Documentation that simply works
---

Welcome to Material for MkDocs.