# Overview

Chavinci is modern blockchain platform designed for token creation, transfer and exchange.

## Key features

While being based on Bitcoin it utilises Proof-of-Stake and native token cration protocol which allow peoples to exchange tokens between each other using atomic swaps.